
const { S3Client, PutObjectCommand, GetObjectCommand } = require('@aws-sdk/client-s3');
const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const FormData = require('form-data');

class UploadService {
    constructor() {
        this.r2Client = new S3Client({
            region: 'auto',
            endpoint: `https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
            credentials: {
                accessKeyId: process.env.R2_ACCESS_KEY,
                secretAccessKey: process.env.R2_SECRET_KEY
            }
        });

        this.supabase = createClient(
            process.env.SUPABASE_URL,
            process.env.SUPABASE_ANON_KEY
        );

        this.cesiumAxios = axios.create({
            baseURL: 'https://api.cesium.com/v1',
            headers: {
                'Authorization': `Bearer ${process.env.CESIUM_ION_ACCESS_TOKEN}`
            }
        });
    }

    async uploadToR2(file) {
        const fileStream = fs.createReadStream(file.path);
        const key = `raw/${Date.now()}-${path.basename(file.originalname)}`;

        const uploadParams = {
            Bucket: process.env.R2_BUCKET,
            Key: key,
            Body: fileStream,
            ContentType: 'application/octet-stream'
        };

        await this.r2Client.send(new PutObjectCommand(uploadParams));

        const publicUrl = `https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com/${process.env.R2_BUCKET}/${key}`;

        return { key, publicUrl };
    }

    async createSupabaseRecord(fileName, r2Key, userId) {
        const { data, error } = await this.supabase
            .from('lidar_files')
            .insert([
                {
                    file_name: fileName,
                    r2_key: r2Key,
                    user_id: userId,
                    status: 'uploaded',
                    created_at: new Date().toISOString()
                }
            ])
            .select()
            .single();

        if (error) throw error;
        return data;
    }

    async uploadToCesium(r2FileUrl, name) {
        const { data: uploadTokenData } = await this.cesiumAxios.post('/assets/upload-token');

        const { data: locationData } = await this.cesiumAxios.post('/assets/upload/location', {
            uploadToken: uploadTokenData.uploadToken
        });

        const formData = new FormData();
        Object.entries(locationData.formFields).forEach(([key, value]) => {
            formData.append(key, value);
        });

        const r2Response = await axios.get(r2FileUrl, { responseType: 'stream' });
        formData.append('file', r2Response.data);

        await axios.post(locationData.url, formData, {
            headers: formData.getHeaders()
        });

        const { data: asset } = await this.cesiumAxios.post('/assets', {
            name,
            description: `Uploaded from LiDAR Viewer`,
            type: '3D_TILES',
            options: {
                sourceType: 'POINT_CLOUD',
                uploadToken: uploadTokenData.uploadToken
            }
        });

        return asset;
    }

    async updateSupabaseWithCesiumInfo(recordId, cesiumAssetId) {
        const { data, error } = await this.supabase
            .from('lidar_files')
            .update({
                cesium_asset_id: cesiumAssetId,
                status: 'processing'
            })
            .eq('id', recordId)
            .select()
            .single();

        if (error) throw error;
        return data;
    }

    async handleUpload(file, userId) {
        try {
            const { key: r2Key, publicUrl: r2FileUrl } = await this.uploadToR2(file);

            const record = await this.createSupabaseRecord(file.originalname, r2Key, userId);

            const cesiumAsset = await this.uploadToCesium(r2FileUrl, file.originalname);

            const updatedRecord = await this.updateSupabaseWithCesiumInfo(record.id, cesiumAsset.id);

            return {
                success: true,
                record: updatedRecord,
                assetId: cesiumAsset.id
            };

        } catch (error) {
            console.error('Upload workflow error:', error);
            throw error;
        } finally {
            fs.unlink(file.path, (err) => {
                if (err) console.error('Error cleaning up temp file:', err);
            });
        }
    }
}

module.exports = UploadService;
